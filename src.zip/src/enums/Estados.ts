export enum Estados {
    NaoIniciado = "Não Iniciado",
    EmProgresso = "Em Progresso",
    Pausado = "Pausado",
    Deletado = "Deletado",
    Finalizado = "Finalizado",
    Aboratdo = "Abortado",
}